package ie.gmit.sw.glitz;

/**
 * Interface class which has the following methods, about
 *
 * @author Eoin Wilkie
 * @version 1.0
 */
public interface Glitz {

	/**
	 * Prints information on on the implementing class
	 */
	void about();

}