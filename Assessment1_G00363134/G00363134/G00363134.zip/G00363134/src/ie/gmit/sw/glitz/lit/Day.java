package ie.gmit.sw.glitz.lit;

/**
 * Enum class which stores Day states
 *
 * @author Eoin Wilkie
 * @version 1.0
 */
public enum Day {
	MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY, SUNDAY, NODAY;
}
