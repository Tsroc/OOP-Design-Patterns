package ie.gmit.sw.glitz.lit;

/**
 * Class which extends AbstractLitField,
 *
 * @author Eoin Wilkie
 * @version 1.0
 */
public class DefaultLitField extends AbstractLitField {

}
